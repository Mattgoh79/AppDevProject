import { env } from "$env/dynamic/private";

const API_BASE_URL = env.API_BASE_URL || "http://localhost:3000";

export const load = async ({ fetch, cookies }) => {
  try {
    const res = await fetch(`${API_BASE_URL}/api/reviews`);
    const result = await res.json();


    const reviews = Array.isArray(result?.data)
      ? result.data
      : Array.isArray(result?.message)
        ? result.message
        : [];

    return {
      reviews,
      username: cookies.get("username") ?? null,
      error: null,
    };
  } catch (err) {
    return {
      reviews: [],
      username: null,
      error: err.message,
    };
  }
};